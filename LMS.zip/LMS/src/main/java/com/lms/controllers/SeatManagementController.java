package com.lms.controllers;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.models.Seat;
import com.lms.services.SeatService;
import com.lms.utils.AlertUtils;
import com.lms.utils.LibraryConfig;
import com.lms.utils.SessionManager;
import com.lms.utils.StageManager;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

@Controller
public class SeatManagementController implements Initializable {
    
    @FXML private Label libraryNameLabel;
    @FXML private Label libraryAddressLabel;
    @FXML private Label libraryPhoneLabel;
    @FXML private Label libraryEmailLabel;
    @FXML private TableView<Seat> seatTable;
    @FXML private TableColumn<Seat, Long> idColumn;
    @FXML private TableColumn<Seat, String> floorColumn;
    @FXML private TableColumn<Seat, String> seatNumberColumn;
    @FXML private TableColumn<Seat, String> statusColumn;
    @FXML private TableColumn<Seat, Seat> actionsColumn;
    @FXML private ComboBox<String> floorFilterComboBox;
    @FXML private ComboBox<String> floorSelectionBox;
    @FXML private ComboBox<String> bulkFloorSelectionBox;
    @FXML private TextField seatNumberField;
    @FXML private TextField bulkStartField;
    @FXML private TextField bulkEndField;
    @FXML private Label totalSeatsLabel;
    @FXML private Label availableSeatsLabel;
    @FXML private Label totalFloorsLabel;
    @FXML private PieChart seatDistributionChart;
    @FXML private ToggleButton showOccupiedToggle;
    @FXML private TextField searchField;
    
    private final SeatService seatService;
    private final StageManager stageManager;
    private final SessionManager sessionManager;
    private final LibraryConfig libraryConfig;
    
    @Autowired
    public SeatManagementController(SeatService seatService, StageManager stageManager, 
                                   SessionManager sessionManager, LibraryConfig libraryConfig) {
        this.seatService = seatService;
        this.stageManager = stageManager;
        this.sessionManager = sessionManager;
        this.libraryConfig = libraryConfig;
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        if (sessionManager.getCurrentAdmin() == null) {
            AlertUtils.showError("Access Denied", "You must be logged in as an administrator.");
            stageManager.showLoginScreen();
            return;
        }
        
        initializeLibraryInfo();
        setupTableColumns();
        setupActionsColumn();
        setupSearchAndFiltering();
        loadData();
    }
    
    private void initializeLibraryInfo() {
        libraryNameLabel.setText(libraryConfig.getLibraryName());
        libraryAddressLabel.setText(libraryConfig.getLibraryAddress());
        libraryPhoneLabel.setText(libraryConfig.getLibraryPhone());
        libraryEmailLabel.setText(libraryConfig.getLibraryEmail());
    }
    
    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        floorColumn.setCellValueFactory(new PropertyValueFactory<>("floor"));
        seatNumberColumn.setCellValueFactory(new PropertyValueFactory<>("seatNumber"));
        statusColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().isAvailable() ? "Available" : "Occupied"));
    }
    
    private void setupSearchAndFiltering() {
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.isEmpty()) {
                filterSeatsBySearch(newValue);
            } else {
                loadSeats();
            }
        });
        
        showOccupiedToggle.selectedProperty().addListener((observable, oldValue, newValue) -> loadSeats());
    }
    
    private void loadData() {
        loadFloorComboBoxes();
        loadSeats();
        updateStats();
        
        if (!floorSelectionBox.getItems().isEmpty()) {
            floorSelectionBox.getSelectionModel().selectFirst();
            bulkFloorSelectionBox.getSelectionModel().selectFirst();
        }
    }
    
    private void setupActionsColumn() {
        actionsColumn.setCellFactory(param -> new TableCell<Seat, Seat>() {
            private final Button deleteBtn = new Button("Delete");
            private final Button toggleBtn = new Button("Toggle");
            private final HBox pane = new HBox(5, deleteBtn, toggleBtn);
            
            {
                deleteBtn.getStyleClass().add("danger-button");
                deleteBtn.setStyle("-fx-font-size: 10px; -fx-padding: 3 8;");
                toggleBtn.getStyleClass().add("primary-button");
                toggleBtn.setStyle("-fx-font-size: 10px; -fx-padding: 3 8;");
                
                deleteBtn.setOnAction(event -> {
                    Seat seat = getTableView().getItems().get(getIndex());
                    handleDeleteSeatById(seat.getId());
                });
                
                toggleBtn.setOnAction(event -> {
                    Seat seat = getTableView().getItems().get(getIndex());
                    toggleSeatAvailability(seat);
                });
            }
            
            @Override
            protected void updateItem(Seat seat, boolean empty) {
                super.updateItem(seat, empty);
                setGraphic(seat == null || empty ? null : pane);
            }
        });
    }
    
    private void filterSeatsBySearch(String searchText) {
        String selectedFloor = floorFilterComboBox.getValue();
        List<Seat> allSeats;
        
        if (selectedFloor == null || selectedFloor.equals("All Floors")) {
            allSeats = seatService.getAllSeats();
        } else {
            allSeats = seatService.getSeatsByFloor(selectedFloor);
        }
        
        if (showOccupiedToggle.isSelected()) {
            allSeats = allSeats.stream()
                .filter(seat -> !seat.isAvailable())
                .collect(Collectors.toList());
        }
        
        List<Seat> filteredSeats = allSeats.stream()
            .filter(seat -> {
                String seatId = seat.getFloor() + "-" + seat.getSeatNumber();
                String searchLower = searchText.toLowerCase();
                return seatId.toLowerCase().contains(searchLower) ||
                       seat.getSeatNumber().toLowerCase().contains(searchLower) ||
                       seat.getFloor().toLowerCase().contains(searchLower);
            })
            .collect(Collectors.toList());
        
        seatTable.setItems(FXCollections.observableArrayList(filteredSeats));
    }
    
    private void toggleSeatAvailability(Seat seat) {
        try {
            seatService.toggleSeatAvailability(seat.getId());
            loadSeats();
            updateStats();
        } catch (Exception e) {
            AlertUtils.showError("Error", "Failed to toggle seat availability: " + e.getMessage());
        }
    }
    
    private void loadFloorComboBoxes() {
        List<String> floors = seatService.getAllFloors();
        
        ObservableList<String> floorOptions = FXCollections.observableArrayList();
        floorOptions.add("All Floors");
        floorOptions.addAll(floors);
        floorFilterComboBox.setItems(floorOptions);
        floorFilterComboBox.getSelectionModel().selectFirst();
        
        ObservableList<String> floorSelectionOptions = FXCollections.observableArrayList(floors);
        floorSelectionBox.setItems(floorSelectionOptions);
        bulkFloorSelectionBox.setItems(floorSelectionOptions);
    }
    
    private void loadSeats() {
        String selectedFloor = floorFilterComboBox.getValue();
        List<Seat> seats;
        
        if (selectedFloor == null || selectedFloor.equals("All Floors")) {
            seats = seatService.getAllSeats();
        } else {
            seats = seatService.getSeatsByFloor(selectedFloor);
        }
        
        if (showOccupiedToggle.isSelected()) {
            seats = seats.stream()
                .filter(seat -> !seat.isAvailable())
                .collect(Collectors.toList());
        }
        
        String searchText = searchField.getText();
        if (searchText != null && !searchText.isEmpty()) {
            String searchLower = searchText.toLowerCase();
            seats = seats.stream()
                .filter(seat -> {
                    String seatId = seat.getFloor() + "-" + seat.getSeatNumber();
                    return seatId.toLowerCase().contains(searchLower) ||
                           seat.getSeatNumber().toLowerCase().contains(searchLower) ||
                           seat.getFloor().toLowerCase().contains(searchLower);
                })
                .collect(Collectors.toList());
        }
        
        seatTable.setItems(FXCollections.observableArrayList(seats));
    }
    
    private void updateStats() {
        totalSeatsLabel.setText(String.valueOf(seatService.getTotalSeats()));
        availableSeatsLabel.setText(String.valueOf(seatService.getAvailableSeatsCount()));
        totalFloorsLabel.setText(String.valueOf(seatService.getAllFloors().size()));
        
        updateSeatDistributionChart();
    }
    
    private void updateSeatDistributionChart() {
        Map<String, Integer> floorStats = seatService.getSeatCountsByFloor();
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        
        floorStats.forEach((floor, count) -> 
            pieChartData.add(new PieChart.Data(floor + " Floor (" + count + ")", count))
        );
        
        seatDistributionChart.setData(pieChartData);
    }
    
    @FXML
    private void handleAddSingleSeat(ActionEvent event) {
        String floor = floorSelectionBox.getValue();
        String seatNumber = seatNumberField.getText().trim();
        
        if (floor == null || floor.isEmpty() || seatNumber.isEmpty()) {
            AlertUtils.showError("Error", "Please select a floor and enter a seat number");
            return;
        }
        
        try {
            seatService.createSeat(floor, seatNumber);
            clearFields();
            refreshSeatData();
            AlertUtils.showInformation("Success", "Seat " + floor + "-" + seatNumber + " added successfully");
        } catch (IllegalArgumentException e) {
            AlertUtils.showError("Error", e.getMessage());
        } catch (Exception e) {
            AlertUtils.showError("Error", "Failed to add seat: " + e.getMessage());
        }
    }
    
    @FXML
    private void handleAddBulkSeats(ActionEvent event) {
        String floor = bulkFloorSelectionBox.getValue();
        String startStr = bulkStartField.getText().trim();
        String endStr = bulkEndField.getText().trim();
        
        if (floor == null || floor.isEmpty() || startStr.isEmpty() || endStr.isEmpty()) {
            AlertUtils.showError("Error", "Please select a floor and enter start and end numbers");
            return;
        }
        
        try {
            int start = Integer.parseInt(startStr);
            int end = Integer.parseInt(endStr);
            
            if (start > end) {
                AlertUtils.showError("Error", "Start number must be less than or equal to end number");
                return;
            }
            
            List<Seat> addedSeats = seatService.createSeatsInBulk(floor, start, end);
            clearFields();
            refreshSeatData();
            AlertUtils.showInformation("Success", addedSeats.size() + " seats added successfully");
        } catch (NumberFormatException e) {
            AlertUtils.showError("Error", "Please enter valid numbers for start and end");
        } catch (IllegalArgumentException e) {
            AlertUtils.showError("Error", e.getMessage());
        } catch (Exception e) {
            AlertUtils.showError("Error", "Failed to add seats: " + e.getMessage());
        }
    }
    
    private void refreshSeatData() {
        loadFloorComboBoxes();
        loadSeats();
        updateStats();
    }
    
    @FXML
    private void handleDeleteSeat(ActionEvent event) {
        Seat selectedSeat = seatTable.getSelectionModel().getSelectedItem();
        if (selectedSeat == null) {
            AlertUtils.showError("Error", "Please select a seat to delete");
            return;
        }
        
        handleDeleteSeatById(selectedSeat.getId());
    }
    
    private void handleDeleteSeatById(Long seatId) {
        boolean confirmed = AlertUtils.showConfirmation(
                "Delete Seat", 
                "Are you sure you want to delete this seat?");
        
        if (confirmed) {
            try {
                seatService.deleteSeat(seatId);
                refreshSeatData();
                AlertUtils.showInformation("Success", "Seat deleted successfully");
            } catch (Exception e) {
                AlertUtils.showError("Error", "Failed to delete seat: " + e.getMessage());
            }
        }
    }
    
    @FXML
    private void handleDeleteAllSeatsInFloor(ActionEvent event) {
        String floor = floorSelectionBox.getValue();
        if (floor == null || floor.isEmpty()) {
            AlertUtils.showError("Error", "Please select a floor");
            return;
        }
        
        boolean confirmed = AlertUtils.showConfirmation(
                "Delete All Seats in Floor", 
                "Are you sure you want to delete ALL seats in floor " + floor + "?");
        
        if (confirmed) {
            try {
                seatService.deleteAllSeatsByFloor(floor);
                refreshSeatData();
                AlertUtils.showInformation("Success", "All seats in floor " + floor + " deleted successfully");
            } catch (Exception e) {
                AlertUtils.showError("Error", "Failed to delete seats: " + e.getMessage());
            }
        }
    }
    
    @FXML
    private void handleFilterChange(ActionEvent event) {
        loadSeats();
    }
    
    @FXML
    private void handleAddNewFloor(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add New Floor");
        dialog.setHeaderText("Enter Floor Code");
        dialog.setContentText("Floor Code (e.g. G, 1, 2):");
        
        dialog.showAndWait().ifPresent(floorCode -> {
            if (!floorCode.isEmpty()) {
                String newFloor = floorCode.trim().toUpperCase();
                
                if (!floorSelectionBox.getItems().contains(newFloor)) {
                    floorSelectionBox.getItems().add(newFloor);
                    bulkFloorSelectionBox.getItems().add(newFloor);
                    
                    if (!floorFilterComboBox.getItems().contains(newFloor) && 
                        !floorFilterComboBox.getItems().isEmpty()) {
                        floorFilterComboBox.getItems().add(newFloor);
                    }
                    
                    floorSelectionBox.setValue(newFloor);
                    bulkFloorSelectionBox.setValue(newFloor);
                    
                    AlertUtils.showInformation("Success", "New floor " + newFloor + " added successfully");
                    updateStats();
                } else {
                    AlertUtils.showInformation("Already Exists", "Floor " + newFloor + " already exists");
                }
            }
        });
    }
    
    @FXML
    private void handleExportSeats(ActionEvent event) {
        AlertUtils.showInformation("Coming Soon", "Export seats to CSV functionality will be implemented in a future update.");
    }
    
    @FXML
    private void handleShowAddSeat(ActionEvent event) {
        // Method called when the "Add your first seat" button in the empty table placeholder is clicked
    }
    
    @FXML
    private void handleClear(ActionEvent event) {
        clearFields();
    }
    
    private void clearFields() {
        seatNumberField.clear();
        bulkStartField.clear();
        bulkEndField.clear();
    }
    
    @FXML
    private void handleBack(ActionEvent event) {
        stageManager.showDashboard();
    }
} 