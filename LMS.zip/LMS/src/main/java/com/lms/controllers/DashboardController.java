package com.lms.controllers;

import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.models.Admin;
import com.lms.models.Shift;
import com.lms.services.AdminService;
import com.lms.services.SeatService;
import com.lms.services.ShiftService;
import com.lms.services.StudentService;
import com.lms.utils.AlertUtils;
import com.lms.utils.LibraryConfig;
import com.lms.utils.SessionManager;
import com.lms.utils.StageManager;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

@Controller
public class DashboardController implements Initializable {

    private StageManager stageManager;
    
    @Autowired
    private AdminService adminService;

    @Autowired
    private ShiftService shiftService;
    
    @Autowired
    private StudentService studentService;
    
    @Autowired
    private SeatService seatService;
    
    @Autowired
    private SessionManager sessionManager;
    
    @Autowired
    private LibraryConfig libraryConfig;
    
    // Default constructor required for FXML
    public DashboardController() {
    }
    
    @Autowired
    public void setStageManager(StageManager stageManager) {
        this.stageManager = stageManager;
    }

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label totalSeatsLabel;

    @FXML
    private Label totalShiftsLabel;

    @FXML
    private Label totalStudentsLabel;

    @FXML
    private TableView<Object[]> shiftsTable;

    @FXML
    private TableColumn<Object[], String> shiftNameColumn;

    @FXML
    private TableColumn<Object[], String> startTimeColumn;

    @FXML
    private TableColumn<Object[], String> endTimeColumn;

    @FXML
    private StackPane contentArea;

    @FXML
    private VBox dashboardView;

    @FXML
    private VBox shiftView;

    @FXML
    private Button studentBtn;

    @FXML
    private Button shiftBtn;

    @FXML
    private Button seatBtn;

    @FXML
    private Button menuToggleBtn;

    @FXML
    private MenuButton adminMenuBtn;

    @FXML
    private Label adminNameLabel;

    @FXML
    private Label adminNameLabel2;

    @FXML
    private Label adminEmailLabel;

    @FXML
    private VBox sidebar;

    @FXML
    private Label libraryNameLabel;

    @FXML
    private Label libraryAddressLabel;

    @FXML
    private Label libraryPhoneLabel;

    @FXML
    private Label libraryEmailLabel;

    @FXML
    private TableView<Object[]> activityTable;

    @FXML
    private Button dashboardBtn;

    @FXML
    private Label menuToggleLabel;

    private boolean sidebarVisible = true;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set library information
        if (libraryNameLabel != null) {
            libraryNameLabel.setText(libraryConfig.getLibraryName());
        }
        
        if (libraryAddressLabel != null) {
            libraryAddressLabel.setText(libraryConfig.getLibraryAddress());
        }
        
        if (libraryPhoneLabel != null) {
            libraryPhoneLabel.setText(libraryConfig.getLibraryPhone());
        }
        
        if (libraryEmailLabel != null) {
            libraryEmailLabel.setText(libraryConfig.getLibraryEmail());
        }
        
        // Initialize dashboard data
        updateDashboardStats();
        setupShiftTable();
        setupActivityTable();
        
        // Set admin information in header only
        Admin admin = sessionManager.getCurrentAdmin();
        if (admin != null) {
            if (adminNameLabel != null) {
                adminNameLabel.setText(admin.getName());
            }
        }
        
        // Show dashboard by default
        showDashboardView();
    }
    
    @FXML
    private void toggleMenu() {
        if (sidebarVisible) {
            // Collapse sidebar to show only icons - hide sidebar completely
            sidebar.setVisible(false);
            sidebar.setManaged(false);
            
            // Change menu toggle button to show only the icon
            menuToggleBtn.setPrefWidth(60);
            menuToggleBtn.setStyle("-fx-background-color: #1a237e; -fx-padding: 12 20; -fx-font-weight: bold; -fx-background-radius: 0; -fx-transition: all 0.3s ease; -fx-alignment: CENTER;");
            
            // Hide the label text in the menu button
            if (menuToggleLabel != null) {
                menuToggleLabel.setVisible(false);
                menuToggleLabel.setManaged(false);
            }
        } else {
            // Show sidebar
            sidebar.setVisible(true);
            sidebar.setManaged(true);
            sidebar.setPrefWidth(250);
            sidebar.setStyle("-fx-background-color: linear-gradient(to bottom, #263238, #37474F); -fx-padding: 0; -fx-transition: all 0.3s ease;");
            
            // Restore full button width and style
            menuToggleBtn.setPrefWidth(250);
            menuToggleBtn.setStyle("-fx-background-color: #1a237e; -fx-padding: 12 20; -fx-font-weight: bold; -fx-background-radius: 0; -fx-transition: all 0.3s ease;");
            
            // Show the label text in the menu button
            if (menuToggleLabel != null) {
                menuToggleLabel.setVisible(true);
                menuToggleLabel.setManaged(true);
            }
        }
        
        sidebarVisible = !sidebarVisible;
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        // Clear session
        sessionManager.setCurrentAdmin(null);
        stageManager.showLoginScreen();
    }

    @FXML
    private void handleResetPassword() {
        stageManager.showResetPassword();
    }
    
    @FXML
    private void handleProfileSettings(ActionEvent event) {
        stageManager.showAdminProfile();
    }

    @FXML
    private void handleLibrarySettings(ActionEvent event) {
        stageManager.showLibrarySettings();
    }

    @FXML
    private void handleDashboardView() {
        // Show dashboard view and hide other views
        if (dashboardView != null) {
            dashboardView.setVisible(true);
        }
        if (shiftView != null) {
            shiftView.setVisible(false);
        }
        
        // Reset button styles
        if (dashboardBtn != null) {
            dashboardBtn.setStyle("-fx-background-color: #37474f;");
        }
        if (shiftBtn != null) {
            shiftBtn.setStyle("-fx-background-color: transparent;");
        }
        if (studentBtn != null) {
            studentBtn.setStyle("-fx-background-color: transparent;");
        }
        if (seatBtn != null) {
            seatBtn.setStyle("-fx-background-color: transparent;");
        }
    }

    @FXML
    private void handleShiftView() {
        // Show shift view and hide dashboard view
        if (dashboardView != null) {
            dashboardView.setVisible(false);
        }
        if (shiftView != null) {
            shiftView.setVisible(true);
        }
        
        // Reset button styles
        if (dashboardBtn != null) {
            dashboardBtn.setStyle("-fx-background-color: transparent;");
        }
        if (shiftBtn != null) {
            shiftBtn.setStyle("-fx-background-color: #37474f;");
        }
        if (studentBtn != null) {
            studentBtn.setStyle("-fx-background-color: transparent;");
        }
        if (seatBtn != null) {
            seatBtn.setStyle("-fx-background-color: transparent;");
        }
    }

    @FXML
    private void handleManageStudents() {
        // Keep the sidebar visible when navigating to student management
        stageManager.showStudentManagement();
        
        // Reset button styles
        dashboardBtn.setStyle("-fx-background-color: transparent;");
        shiftBtn.setStyle("-fx-background-color: transparent;");
        studentBtn.setStyle("-fx-background-color: #37474f;");
        seatBtn.setStyle("-fx-background-color: transparent;");
    }

    @FXML
    private void handleSeatManagement() {
        // Keep the sidebar visible when navigating to seat management
        stageManager.showSeatManagement();
        
        // Reset button styles
        dashboardBtn.setStyle("-fx-background-color: transparent;");
        shiftBtn.setStyle("-fx-background-color: transparent;");
        studentBtn.setStyle("-fx-background-color: transparent;");
        seatBtn.setStyle("-fx-background-color: #37474f;");
    }

    @FXML
    private void handleAddShift() {
        Dialog<Shift> dialog = createShiftDialog(null);
        dialog.showAndWait().ifPresent(shift -> {
            try {
                shiftService.createShift(shift.getShiftName(), shift.getStartTime(), shift.getEndTime());
                // Refresh the table
                List<Shift> shifts = shiftService.getAllShifts();
                shiftsTable.setItems(FXCollections.observableArrayList(shiftService.getAllShiftsAsArray()));
                totalShiftsLabel.setText(String.valueOf(shifts.size()));
            } catch (Exception e) {
                showAlert("Error", "Failed to save shift: " + e.getMessage());
            }
        });
    }

    @FXML
    private void handleEditShift() {
        Object[] selected = shiftsTable.getSelectionModel().getSelectedItem();
        if (selected == null || selected.length == 0) {
            showAlert("No Selection", "Please select a shift to edit.");
            return;
        }
        
        Shift selectedShift = (Shift) selected[0];
        Dialog<Shift> dialog = createShiftDialog(selectedShift);
        dialog.showAndWait().ifPresent(shift -> {
            try {
                shiftService.updateShift(selectedShift.getId(), shift.getShiftName(), 
                                         shift.getStartTime(), shift.getEndTime());
                // Refresh the table
                List<Shift> shifts = shiftService.getAllShifts();
                shiftsTable.setItems(FXCollections.observableArrayList(shiftService.getAllShiftsAsArray()));
                totalShiftsLabel.setText(String.valueOf(shifts.size()));
            } catch (Exception e) {
                showAlert("Error", "Failed to update shift: " + e.getMessage());
            }
        });
    }

    @FXML
    private void handleDeleteShift() {
        Object[] selected = shiftsTable.getSelectionModel().getSelectedItem();
        if (selected == null || selected.length == 0) {
            showAlert("No Selection", "Please select a shift to delete.");
            return;
        }
        
        Shift selectedShift = (Shift) selected[0];
        try {
            shiftService.deleteShift(selectedShift.getId());
            // Refresh the table
            List<Shift> shifts = shiftService.getAllShifts();
            shiftsTable.setItems(FXCollections.observableArrayList(shiftService.getAllShiftsAsArray()));
            totalShiftsLabel.setText(String.valueOf(shifts.size()));
        } catch (Exception e) {
            showAlert("Error", "Failed to delete shift: " + e.getMessage());
        }
    }
    
    @FXML
    private void handleClearAllSeats() {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Clear All Seats");
        confirmAlert.setHeaderText("Are you sure?");
        confirmAlert.setContentText("This will delete ALL seats from the database. This action cannot be undone.");
        
        confirmAlert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    seatService.deleteAllSeats();
                    updateDashboardStats();
                    AlertUtils.showInformation("Success", "All seats have been removed from the database.");
                } catch (Exception e) {
                    AlertUtils.showError("Failed to clear seats: " + e.getMessage());
                }
            }
        });
    }

    private Dialog<Shift> createShiftDialog(Shift existingShift) {
        Dialog<Shift> dialog = new Dialog<>();
        dialog.setTitle(existingShift == null ? "Add Shift" : "Edit Shift");

        // Create the dialog content
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new javafx.geometry.Insets(25, 25, 25, 25));
        grid.setStyle("-fx-background-color: white;");
        
        Label headerLabel = new Label(existingShift == null ? "Add New Shift" : "Edit Shift Information");
        headerLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #3949ab; -fx-font-family: 'Segoe UI';");
        GridPane.setColumnSpan(headerLabel, 2);
        GridPane.setHalignment(headerLabel, javafx.geometry.HPos.CENTER);
        grid.add(headerLabel, 0, 0);

        // Create styled form fields with prompts
        TextField nameField = new TextField();
        nameField.setPromptText("Enter shift name");
        nameField.setPrefWidth(300);
        nameField.setStyle("-fx-font-family: 'Segoe UI';");
        
        TextField startTimeField = new TextField();
        startTimeField.setPromptText("HH:mm (24-hour format)");
        startTimeField.setStyle("-fx-font-family: 'Segoe UI';");
        
        TextField endTimeField = new TextField();
        endTimeField.setPromptText("HH:mm (24-hour format)");
        endTimeField.setStyle("-fx-font-family: 'Segoe UI';");

        if (existingShift != null) {
            nameField.setText(existingShift.getShiftName());
            startTimeField.setText(existingShift.getStartTime().format(DateTimeFormatter.ofPattern("HH:mm")));
            endTimeField.setText(existingShift.getEndTime().format(DateTimeFormatter.ofPattern("HH:mm")));
        }

        // Create styled labels
        Label nameLabel = new Label("Shift Name:");
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Label startTimeLabel = new Label("Start Time:");
        startTimeLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Label endTimeLabel = new Label("End Time:");
        endTimeLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");

        // Add components to grid with some spacing
        grid.add(nameLabel, 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(startTimeLabel, 0, 2);
        grid.add(startTimeField, 1, 2);
        grid.add(endTimeLabel, 0, 3);
        grid.add(endTimeField, 1, 3);

        dialog.getDialogPane().setContent(grid);
        
        // Style dialog buttons
        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);
        
        Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Button cancelButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.CANCEL);
        cancelButton.setStyle("-fx-font-family: 'Segoe UI';");
        
        // Set minimum width and apply styles to dialog pane
        dialog.getDialogPane().setMinWidth(450);
        dialog.getDialogPane().setStyle("-fx-background-color: white; -fx-border-color: #3949ab; -fx-border-width: 2px;");

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    Shift shift = new Shift();
                    shift.setShiftName(nameField.getText());
                    shift.setStartTime(LocalTime.parse(startTimeField.getText(), DateTimeFormatter.ofPattern("HH:mm")));
                    shift.setEndTime(LocalTime.parse(endTimeField.getText(), DateTimeFormatter.ofPattern("HH:mm")));
                    return shift;
                } catch (Exception e) {
                    showAlert("Error", "Invalid time format. Please use HH:mm format.");
                    return null;
                }
            }
            return null;
        });

        return dialog;
    }

    private void updateDashboardStats() {
        // Update total seats
        int totalSeats = shiftService.getTotalSeats();
        totalSeatsLabel.setText(String.valueOf(totalSeats));

        // Update total shifts
        int totalShifts = shiftService.getTotalShifts();
        totalShiftsLabel.setText(String.valueOf(totalShifts));

        // Update total students
        int totalStudents = studentService.getTotalStudents();
        totalStudentsLabel.setText(String.valueOf(totalStudents));
    }

    private void setupShiftTable() {
        // Configure shift table columns
        shiftNameColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(((Shift)cellData.getValue()[0]).getShiftName()));
        
        startTimeColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue()[1].toString()));
        
        endTimeColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue()[2].toString()));

        // Load shift data
        shiftsTable.setItems(FXCollections.observableArrayList(shiftService.getAllShiftsAsArray()));
    }

    private void setupActivityTable() {
        // Configure activity table (placeholder for now)
        // This would be implemented based on activity logging requirements
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        
        // Style the alert dialog
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #f44336;" +
            "-fx-border-width: 2px;" +
            "-fx-font-family: 'Segoe UI';"
        );
        
        // Style the buttons
        Button okButton = (Button) dialogPane.lookupButton(ButtonType.OK);
        okButton.setStyle(
            "-fx-background-color: #f44336;" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-family: 'Segoe UI';"
        );
        
        alert.showAndWait();
    }

    // Show dashboard view by default (private method)
    private void showDashboardView() {
        // Show dashboard and hide other views
        dashboardView.setVisible(true);
        shiftView.setVisible(false);
        
        // Set dashboard button style to active
        if (dashboardBtn != null) {
            dashboardBtn.setStyle("-fx-background-color: #37474f;");
            shiftBtn.setStyle("-fx-background-color: transparent;");
            studentBtn.setStyle("-fx-background-color: transparent;");
            seatBtn.setStyle("-fx-background-color: transparent;");
        }
    }
} 