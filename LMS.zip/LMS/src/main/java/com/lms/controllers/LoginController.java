package com.lms.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.services.AdminService;
import com.lms.utils.SessionManager;
import com.lms.utils.StageManager;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

@Controller
public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private StageManager stageManager;
    private AdminService adminService;
    private SessionManager sessionManager;
    
    // Default constructor required for FXML
    public LoginController() {
    }
    
    @Autowired
    public void setServices(AdminService adminService, StageManager stageManager, SessionManager sessionManager) {
        this.adminService = adminService;
        this.stageManager = stageManager;
        this.sessionManager = sessionManager;
    }

    @FXML
    public void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        
        try {
            if (username.isEmpty() || password.isEmpty()) {
                showErrorMessage("Username and password cannot be empty");
                return;
            }
            
            // Temporary login bypass for testing - allows login with admin/admin when services are unavailable
            boolean success = false;
            
            // First check if sessionManager is null
            if (sessionManager == null) {
                System.out.println("Warning: SessionManager is null, using testing fallback");
                // Testing fallback: allow admin/admin to work
                if ("admin".equals(username) && "admin".equals(password)) {
                    success = true;
                    System.out.println("Test login successful with admin/admin");
                } else {
                    showErrorMessage("System error: Authentication service unavailable.\nUse admin/admin for testing.");
                    return;
                }
            } else {
                success = sessionManager.authenticate(username, password);
            }
            
            if (success) {
                // Successful login
                if (stageManager != null) {
                    stageManager.showDashboard();
                } else {
                    System.out.println("Cannot show dashboard: StageManager is null");
                    // For testing purposes, show a success message instead
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Login Success");
                    alert.setHeaderText("Welcome to Library Management System");
                    alert.setContentText("Login successful! Dashboard navigation is unavailable in testing mode.");
                    alert.showAndWait();
                }
            } else {
                // Failed login
                showErrorMessage("Invalid username or password");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showErrorMessage("Login error: " + e.getMessage());
        }
    }

    @FXML
    private void handleResetPassword() {
        try {
            if (stageManager != null) {
                stageManager.showResetPassword();
            } else {
                // For now, just print to console as a fallback if stageManager is null
                System.out.println("Cannot show reset password screen: StageManager is null");
                // Show an alert to the user
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("System Error");
                alert.setContentText("Unable to open reset password screen. Please try again later.");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Show error dialog
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("System Error");
            alert.setContentText("An error occurred: " + e.getMessage());
            alert.showAndWait();
        }
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
} 