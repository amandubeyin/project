package com.lms.controllers;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.utils.AlertUtils;
import com.lms.utils.LibraryConfig;
import com.lms.utils.SessionManager;
import com.lms.utils.StageManager;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

@Controller
public class LibrarySettingsController {
    
    @FXML
    private TextField libraryNameField;
    
    @FXML
    private TextField libraryAddressField;
    
    @FXML
    private TextField libraryPhoneField;
    
    @FXML
    private TextField libraryEmailField;
    
    @FXML
    private TextField libraryWebsiteField;
    
    private final StageManager stageManager;
    private final SessionManager sessionManager;
    private final LibraryConfig libraryConfig;
    private final String propertiesPath = "src/main/resources/application.properties";
    
    @Autowired
    public LibrarySettingsController(StageManager stageManager, SessionManager sessionManager, LibraryConfig libraryConfig) {
        this.stageManager = stageManager;
        this.sessionManager = sessionManager;
        this.libraryConfig = libraryConfig;
    }
    
    @FXML
    public void initialize() {
        // Check if user is admin
        if (sessionManager.getCurrentAdmin() == null) {
            AlertUtils.showError("Error", "You must be logged in as an administrator to access settings.");
            stageManager.showLoginScreen();
            return;
        }
        
        // Load current settings
        libraryNameField.setText(libraryConfig.getLibraryName());
        libraryAddressField.setText(libraryConfig.getLibraryAddress());
        libraryPhoneField.setText(libraryConfig.getLibraryPhone());
        libraryEmailField.setText(libraryConfig.getLibraryEmail());
        libraryWebsiteField.setText(libraryConfig.getLibraryWebsite());
    }
    
    @FXML
    private void handleSave(ActionEvent event) {
        String name = libraryNameField.getText().trim();
        String address = libraryAddressField.getText().trim();
        String phone = libraryPhoneField.getText().trim();
        String email = libraryEmailField.getText().trim();
        String website = libraryWebsiteField.getText().trim();
        
        if (name.isEmpty()) {
            AlertUtils.showError("Library name cannot be empty");
            return;
        }
        
        // Save settings to application.properties
        try {
            Properties properties = new Properties();
            // Load existing properties
            try (FileInputStream in = new FileInputStream(propertiesPath)) {
                properties.load(in);
            }
            
            // Update library properties
            properties.setProperty("library.name", name);
            properties.setProperty("library.address", address);
            properties.setProperty("library.phone", phone);
            properties.setProperty("library.email", email);
            properties.setProperty("library.website", website);
            
            // Save properties back to file
            try (FileOutputStream out = new FileOutputStream(propertiesPath)) {
                properties.store(out, "Updated library settings");
            }
            
            AlertUtils.showInformation("Success", "Library settings updated successfully.\nPlease restart the application for changes to take effect.");
            stageManager.showDashboard();
        } catch (IOException e) {
            AlertUtils.showError("Error saving settings", e.getMessage());
        }
    }
    
    @FXML
    private void handleCancel(ActionEvent event) {
        stageManager.showDashboard();
    }
} 