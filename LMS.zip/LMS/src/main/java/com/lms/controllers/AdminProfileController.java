package com.lms.controllers;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.models.Admin;
import com.lms.services.AdminService;
import com.lms.utils.AlertUtils;
import com.lms.utils.LibraryConfig;
import com.lms.utils.SessionManager;
import com.lms.utils.StageManager;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

@Controller
public class AdminProfileController {
    
    @FXML
    private Label titleLabel;
    
    @FXML
    private TextField userIdField;
    
    @FXML
    private TextField usernameField;
    
    @FXML
    private TextField emailField;
    
    @FXML
    private TextField fullNameField;
    
    @FXML
    private DatePicker dobPicker;
    
    @FXML
    private TextField roleField;
    
    @FXML
    private TextField lastLoginField;
    
    @FXML
    private Label libraryNameLabel;
    
    @FXML
    private Label libraryAddressLabel;
    
    @FXML
    private Label libraryPhoneLabel;
    
    @FXML
    private Label libraryEmailLabel;
    
    private final StageManager stageManager;
    private final AdminService adminService;
    private final SessionManager sessionManager;
    private final LibraryConfig libraryConfig;
    private Admin currentAdmin;
    private boolean editMode = false;
    
    @Autowired
    public AdminProfileController(AdminService adminService, StageManager stageManager, 
                                 SessionManager sessionManager, LibraryConfig libraryConfig) {
        this.adminService = adminService;
        this.stageManager = stageManager;
        this.sessionManager = sessionManager;
        this.libraryConfig = libraryConfig;
    }
    
    @FXML
    public void initialize() {
        currentAdmin = sessionManager.getCurrentAdmin();
        
        if (currentAdmin != null) {
            loadAdminProfile();
        } else {
            AlertUtils.showError("Error", "No admin is currently logged in.");
            stageManager.showLoginScreen();
        }
        
        setFieldsEditable(false);
        
        // Initialize library information labels
        if (libraryNameLabel != null) {
            libraryNameLabel.setText(libraryConfig.getLibraryName());
        }
        
        if (libraryAddressLabel != null) {
            libraryAddressLabel.setText(libraryConfig.getLibraryAddress());
        }
        
        if (libraryPhoneLabel != null) {
            libraryPhoneLabel.setText(libraryConfig.getLibraryPhone());
        }
        
        if (libraryEmailLabel != null) {
            libraryEmailLabel.setText(libraryConfig.getLibraryEmail());
        }
    }
    
    private void loadAdminProfile() {
        userIdField.setText(String.valueOf(currentAdmin.getId()));
        usernameField.setText(currentAdmin.getUsername());
        emailField.setText(currentAdmin.getEmail());
        fullNameField.setText(currentAdmin.getFullName());
        dobPicker.setValue(currentAdmin.getDateOfBirth());
        roleField.setText("Administrator");
        lastLoginField.setText(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }
    
    private void setFieldsEditable(boolean editable) {
        userIdField.setEditable(false); // ID should never be editable
        usernameField.setEditable(false); // Username should never be editable
        emailField.setEditable(editable);
        fullNameField.setEditable(editable);
        dobPicker.setDisable(!editable);
        roleField.setEditable(false); // Role should never be editable
        lastLoginField.setEditable(false); // Last login should never be editable
        
        titleLabel.setText(editable ? "Edit Profile" : "Admin Profile");
    }
    
    @FXML
    private void handleEditToggle(ActionEvent event) {
        editMode = !editMode;
        setFieldsEditable(editMode);
    }
    
    @FXML
    private void handleSave(ActionEvent event) {
        if (!editMode) {
            return;
        }
        
        String email = emailField.getText().trim();
        String fullName = fullNameField.getText().trim();
        LocalDate dob = dobPicker.getValue();
        
        if (email.isEmpty() || fullName.isEmpty() || dob == null) {
            AlertUtils.showError("All fields are required");
            return;
        }
        
        currentAdmin.setEmail(email);
        currentAdmin.setFullName(fullName);
        currentAdmin.setDateOfBirth(dob);
        
        boolean success = adminService.updateAdminProfile(currentAdmin);
        
        if (success) {
            AlertUtils.showInformation("Success", "Profile updated successfully.");
            editMode = false;
            setFieldsEditable(false);
            
            // Update session admin
            sessionManager.setCurrentAdmin(currentAdmin);
        } else {
            AlertUtils.showError("Failed to update profile");
        }
    }
    
    @FXML
    private void handleCancel(ActionEvent event) {
        if (editMode) {
            // Reload original data
            loadAdminProfile();
            editMode = false;
            setFieldsEditable(false);
        } else {
            stageManager.showDashboard();
        }
    }
    
    @FXML
    private void handleResetPassword(ActionEvent event) {
        stageManager.showResetPassword();
    }
    
    @FXML
    private void handleLibrarySettings(ActionEvent event) {
        stageManager.showLibrarySettings();
    }
    
    @FXML
    private void handleDashboard(ActionEvent event) {
        stageManager.showDashboard();
    }
} 