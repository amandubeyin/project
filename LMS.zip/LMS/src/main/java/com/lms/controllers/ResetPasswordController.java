package com.lms.controllers;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.services.AdminService;
import com.lms.utils.AlertUtils;
import com.lms.utils.SessionManager;
import com.lms.utils.StageManager;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

@Controller
public class ResetPasswordController {
    
    @FXML
    private TextField usernameField;
    
    @FXML
    private DatePicker dobPicker;
    
    @FXML
    private PasswordField newPasswordField;
    
    @FXML
    private PasswordField confirmPasswordField;
    
    private final StageManager stageManager;
    private final AdminService adminService;
    private final SessionManager sessionManager;
    
    @Autowired
    public ResetPasswordController(AdminService adminService, StageManager stageManager, SessionManager sessionManager) {
        this.adminService = adminService;
        this.stageManager = stageManager;
        this.sessionManager = sessionManager;
    }
    
    @FXML
    private void handleResetPassword(ActionEvent event) {
        String username = usernameField.getText().trim();
        LocalDate dob = dobPicker.getValue();
        String newPassword = newPasswordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        
        if (username.isEmpty() || dob == null || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            AlertUtils.showError("All fields are required");
            return;
        }
        
        if (!newPassword.equals(confirmPassword)) {
            AlertUtils.showError("Passwords do not match");
            return;
        }
        
        // Simple password hashing (in a real app, use a proper hashing library)
        String hashedPassword = String.valueOf(newPassword.hashCode());
        
        boolean success = adminService.resetPassword(username, dob, hashedPassword);
        
        if (success) {
            AlertUtils.showInformation("Password Reset Successful", "Your password has been reset successfully.");
            stageManager.showLoginScreen();
        } else {
            AlertUtils.showError("Invalid Information", "The username or date of birth is incorrect.");
        }
    }
    
    @FXML
    private void handleCancel(ActionEvent event) {
        stageManager.showLoginScreen();
    }
} 