package com.lms.controllers;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.lms.services.AdminService;
import com.lms.services.SystemInitializationService;
import com.lms.utils.AlertUtils;
import com.lms.utils.StageManager;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

@Controller
public class SetupController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField fullNameField;
    
    @FXML
    private DatePicker dobPicker;

    private SystemInitializationService systemInitService;
    private AdminService adminService;
    private StageManager stageManager;
    
    // Default values for system configuration
    private static final int DEFAULT_TOTAL_SEATS = 100;
    private static final int DEFAULT_NUMBER_OF_SHIFTS = 3;
    
    // Default no-arg constructor required for FXML
    public SetupController() {
    }

    @Autowired
    public void setServices(SystemInitializationService systemInitService, AdminService adminService, StageManager stageManager) {
        this.systemInitService = systemInitService;
        this.adminService = adminService;
        this.stageManager = stageManager;
    }

    @FXML
    public void handleInitialize() {
        try {
            // Use default values for seats and shifts
            int totalSeats = DEFAULT_TOTAL_SEATS;
            int numberOfShifts = DEFAULT_NUMBER_OF_SHIFTS;
            
            String username = usernameField.getText().trim();
            String password = passwordField.getText();
            String email = emailField.getText().trim();
            String fullName = fullNameField.getText().trim();
            LocalDate dob = dobPicker.getValue();

            if (username.isEmpty() || password.isEmpty() || email.isEmpty() || fullName.isEmpty() || dob == null) {
                AlertUtils.showError("All fields are required.");
                return;
            }

            // Simple password hashing (in a real app, use a proper hashing library)
            String hashedPassword = String.valueOf(password.hashCode());
            
            // Create admin account
            boolean adminCreated = adminService.createAdmin(username, hashedPassword, email, fullName, dob);
            
            if (!adminCreated) {
                AlertUtils.showError("Failed to create admin account.");
                return;
            }

            // Initialize system configuration
            boolean systemInitialized = systemInitService.initializeSystem(totalSeats, numberOfShifts);
            
            if (!systemInitialized) {
                AlertUtils.showError("Failed to initialize system.");
                return;
            }

            AlertUtils.showInformation("Success", "System initialized successfully!");
            stageManager.showLoginScreen();
        } catch (Exception e) {
            AlertUtils.showError("An error occurred during initialization: " + e.getMessage());
        }
    }
} 