package com.lms.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lms.models.Student;
import com.lms.services.StudentService;
import com.lms.utils.StageManager;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

@Component
public class StudentController {

    @FXML
    private TableView<Student> studentsTable;
    
    @FXML
    private TableColumn<Student, Long> idColumn;
    
    @FXML
    private TableColumn<Student, String> nameColumn;
    
    @FXML
    private TableColumn<Student, String> fatherNameColumn;
    
    @FXML
    private TableColumn<Student, String> genderColumn;
    
    @FXML
    private TableColumn<Student, String> addressColumn;
    
    @FXML
    private TableColumn<Student, String> mobileNoColumn;
    
    @FXML
    private TextField searchField;
    
    private final StudentService studentService;
    private final StageManager stageManager;
    
    @Autowired
    public StudentController(StudentService studentService, StageManager stageManager) {
        this.studentService = studentService;
        this.stageManager = stageManager;
    }
    
    @FXML
    public void initialize() {
        setupTableColumns();
        loadAllStudents();
    }
    
    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        fatherNameColumn.setCellValueFactory(new PropertyValueFactory<>("fatherName"));
        genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        mobileNoColumn.setCellValueFactory(new PropertyValueFactory<>("mobileNo"));
    }
    
    private void loadAllStudents() {
        List<Student> students = studentService.getAllStudents();
        studentsTable.getItems().setAll(students);
    }
    
    @FXML
    public void handleSearch() {
        String searchTerm = searchField.getText();
        List<Student> students = studentService.searchStudents(searchTerm);
        studentsTable.getItems().setAll(students);
    }
    
    @FXML
    public void handleAddStudent() {
        Dialog<Student> dialog = createStudentDialog(null);
        dialog.showAndWait().ifPresent(student -> {
            studentService.createStudent(
                student.getName(),
                student.getFatherName(),
                student.getGender(),
                student.getAddress(),
                student.getMobileNo()
            );
            loadAllStudents();
        });
    }
    
    @FXML
    public void handleEditStudent() {
        Student selectedStudent = studentsTable.getSelectionModel().getSelectedItem();
        if (selectedStudent != null) {
            Dialog<Student> dialog = createStudentDialog(selectedStudent);
            dialog.showAndWait().ifPresent(student -> {
                studentService.updateStudent(
                    selectedStudent.getId(),
                    student.getName(),
                    student.getFatherName(),
                    student.getGender(),
                    student.getAddress(),
                    student.getMobileNo()
                );
                loadAllStudents();
            });
        } else {
            showAlert("Error", "Please select a student to edit.");
        }
    }
    
    @FXML
    public void handleDeleteStudent() {
        Student selectedStudent = studentsTable.getSelectionModel().getSelectedItem();
        if (selectedStudent != null) {
            studentService.deleteStudent(selectedStudent.getId());
            loadAllStudents();
        } else {
            showAlert("Error", "Please select a student to delete.");
        }
    }
    
    @FXML
    public void handleBackToDashboard() {
        stageManager.showDashboard();
    }
    
    private Dialog<Student> createStudentDialog(Student existingStudent) {
        Dialog<Student> dialog = new Dialog<>();
        dialog.setTitle(existingStudent == null ? "Add Student" : "Edit Student");
        
        // Create the dialog content
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(25, 25, 25, 25));
        grid.setStyle("-fx-background-color: white;");
        
        Label headerLabel = new Label(existingStudent == null ? "Add New Student" : "Edit Student Information");
        headerLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #3949ab; -fx-font-family: 'Segoe UI';");
        GridPane.setColumnSpan(headerLabel, 2);
        GridPane.setHalignment(headerLabel, javafx.geometry.HPos.CENTER);
        grid.add(headerLabel, 0, 0);
        
        // Create styled form fields
        TextField nameField = new TextField();
        nameField.setPromptText("Enter student name");
        nameField.setPrefWidth(300);
        nameField.setStyle("-fx-font-family: 'Segoe UI';");
        
        TextField fatherNameField = new TextField();
        fatherNameField.setPromptText("Enter father's name");
        fatherNameField.setStyle("-fx-font-family: 'Segoe UI';");
        
        ComboBox<String> genderComboBox = new ComboBox<>(
            FXCollections.observableArrayList("Male", "Female", "Other")
        );
        genderComboBox.setPromptText("Select gender");
        genderComboBox.setStyle("-fx-font-family: 'Segoe UI';");
        
        TextField addressField = new TextField();
        addressField.setPromptText("Enter address");
        addressField.setStyle("-fx-font-family: 'Segoe UI';");
        
        TextField mobileNoField = new TextField();
        mobileNoField.setPromptText("Enter mobile number");
        mobileNoField.setStyle("-fx-font-family: 'Segoe UI';");
        
        if (existingStudent != null) {
            nameField.setText(existingStudent.getName());
            fatherNameField.setText(existingStudent.getFatherName());
            genderComboBox.setValue(existingStudent.getGender());
            addressField.setText(existingStudent.getAddress());
            mobileNoField.setText(existingStudent.getMobileNo());
        }
        
        // Create styled labels
        Label nameLabel = new Label("Name:");
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Label fatherNameLabel = new Label("Father's Name:");
        fatherNameLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Label genderLabel = new Label("Gender:");
        genderLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Label addressLabel = new Label("Address:");
        addressLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Label mobileNoLabel = new Label("Mobile No:");
        mobileNoLabel.setStyle("-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        // Add components to grid with some spacing
        grid.add(nameLabel, 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(fatherNameLabel, 0, 2);
        grid.add(fatherNameField, 1, 2);
        grid.add(genderLabel, 0, 3);
        grid.add(genderComboBox, 1, 3);
        grid.add(addressLabel, 0, 4);
        grid.add(addressField, 1, 4);
        grid.add(mobileNoLabel, 0, 5);
        grid.add(mobileNoField, 1, 5);
        
        dialog.getDialogPane().setContent(grid);
        
        // Style dialog buttons
        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);
        
        Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-family: 'Segoe UI';");
        
        Button cancelButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.CANCEL);
        cancelButton.setStyle("-fx-font-family: 'Segoe UI';");
        
        // Set minimum width and apply styles to dialog pane
        dialog.getDialogPane().setMinWidth(500);
        dialog.getDialogPane().setStyle("-fx-background-color: white; -fx-border-color: #3949ab; -fx-border-width: 2px;");
        
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                Student student = new Student();
                student.setName(nameField.getText());
                student.setFatherName(fatherNameField.getText());
                student.setGender(genderComboBox.getValue());
                student.setAddress(addressField.getText());
                student.setMobileNo(mobileNoField.getText());
                return student;
            }
            return null;
        });
        
        return dialog;
    }
    
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        
        // Style the alert dialog
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #f44336;" +
            "-fx-border-width: 2px;" +
            "-fx-font-family: 'Segoe UI';"
        );
        
        // Style the buttons
        Button okButton = (Button) dialogPane.lookupButton(ButtonType.OK);
        okButton.setStyle(
            "-fx-background-color: #f44336;" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-family: 'Segoe UI';"
        );
        
        alert.showAndWait();
    }
} 