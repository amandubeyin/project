package com.lms.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SystemConfig {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    private Integer totalSeats;
    private Integer numberOfShifts;
    private Boolean isInitialized = false;
    
    public SystemConfig() {
    }
    
    public SystemConfig(Integer totalSeats, Integer numberOfShifts, Boolean isInitialized) {
        this.totalSeats = totalSeats;
        this.numberOfShifts = numberOfShifts;
        this.isInitialized = isInitialized;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public Integer getTotalSeats() {
        return totalSeats;
    }
    
    public void setTotalSeats(Integer totalSeats) {
        this.totalSeats = totalSeats;
    }
    
    public Integer getNumberOfShifts() {
        return numberOfShifts;
    }
    
    public void setNumberOfShifts(Integer numberOfShifts) {
        this.numberOfShifts = numberOfShifts;
    }
    
    public Boolean getIsInitialized() {
        return isInitialized;
    }
    
    public void setIsInitialized(Boolean isInitialized) {
        this.isInitialized = isInitialized;
    }
} 