package com.lms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.lms.models.Seat;

@Repository
public interface SeatRepository extends JpaRepository<Seat, Long> {
    
    List<Seat> findByFloor(String floor);
    
    List<Seat> findByIsAvailable(boolean isAvailable);
    
    List<Seat> findByFloorAndIsAvailable(String floor, boolean isAvailable);
    
    @Query("SELECT COUNT(s) FROM Seat s")
    int countTotalSeats();
    
    @Query("SELECT COUNT(s) FROM Seat s WHERE s.isAvailable = true")
    int countAvailableSeats();
    
    @Query("SELECT COUNT(s) FROM Seat s WHERE s.floor = ?1")
    int countSeatsByFloor(String floor);
    
    @Query("SELECT DISTINCT s.floor FROM Seat s ORDER BY s.floor")
    List<String> findAllFloors();
    
    boolean existsBySeatNumberAndFloor(String seatNumber, String floor);
} 