package com.lms.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lms.models.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    
    // Find students by name (containing the search term)
    List<Student> findByNameContainingIgnoreCase(String name);
    
    // Find students by mobile number (containing the search term)
    List<Student> findByMobileNoContaining(String mobileNo);
    
    // Find students by either name or mobile number
    List<Student> findByNameContainingIgnoreCaseOrMobileNoContaining(String name, String mobileNo);
} 