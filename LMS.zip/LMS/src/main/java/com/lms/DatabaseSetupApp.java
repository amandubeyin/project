package com.lms;

import javax.persistence.EntityManagerFactory;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

public class DatabaseSetupApp {
    
    public static void main(String[] args) {
        try {
            System.out.println("Starting database initialization...");
            
            // Initialize Spring context
            AnnotationConfigApplicationContext context = 
                new AnnotationConfigApplicationContext(AppConfig.class);
            
            // Get the EntityManagerFactory to trigger schema creation
            EntityManagerFactory emf = context.getBean(LocalContainerEntityManagerFactoryBean.class)
                .getObject();
            
            System.out.println("Database initialization completed successfully!");
            
            // Close the context
            context.close();
            
        } catch (Exception e) {
            System.err.println("Error initializing database: " + e.getMessage());
            e.printStackTrace();
        }
    }
} 