package com.lms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.ApplicationEvent;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class LibraryManagementSystemApplication extends Application {

    private ApplicationContext applicationContext;
    private static String[] savedArgs;

    @Override
    public void init() throws Exception {
        applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
    }

    @Override
    public void start(Stage primaryStage) {
        applicationContext.publishEvent(new StageReadyEvent(primaryStage));
    }

    @Override
    public void stop() throws Exception {
        Platform.exit();
    }

    public static void main(String[] args) {
        savedArgs = args;
        launch(args);
    }

    public static class StageReadyEvent extends ApplicationEvent {
        private final Stage stage;

        public StageReadyEvent(Stage stage) {
            super(stage);
            this.stage = stage;
        }

        public Stage getStage() {
            return stage;
        }
    }
} 