package com.lms.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.models.Student;
import com.lms.repositories.StudentRepository;

@Service
public class StudentService {
    
    private final StudentRepository studentRepository;
    
    @Autowired
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }
    
    public Student createStudent(String name, String fatherName, String gender, String address, String mobileNo) {
        Student student = new Student(name, fatherName, gender, address, mobileNo);
        return studentRepository.save(student);
    }
    
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }
    
    public List<Student> searchStudents(String searchTerm) {
        // Search by name or mobile number
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllStudents();
        }
        return studentRepository.findByNameContainingIgnoreCaseOrMobileNoContaining(searchTerm, searchTerm);
    }
    
    public Student updateStudent(Long id, String name, String fatherName, String gender, String address, String mobileNo) {
        Optional<Student> optionalStudent = studentRepository.findById(id);
        if (optionalStudent.isPresent()) {
            Student student = optionalStudent.get();
            student.setName(name);
            student.setFatherName(fatherName);
            student.setGender(gender);
            student.setAddress(address);
            student.setMobileNo(mobileNo);
            return studentRepository.save(student);
        }
        return null;
    }
    
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
    
    /**
     * Get the total number of students in the system
     * @return Count of students
     */
    public int getTotalStudents() {
        return (int) studentRepository.count();
    }
} 