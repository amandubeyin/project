package com.lms.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.models.SystemConfig;
import com.lms.repositories.SystemConfigRepository;

@Service
public class SystemInitializationService {

    @Autowired
    private SystemConfigRepository systemConfigRepository;

    public boolean isSystemInitialized() {
        try {
            SystemConfig config = systemConfigRepository.findFirstByOrderById();
            return config != null && config.getIsInitialized();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean initializeSystem(int totalSeats, int numberOfShifts) {
        try {
            SystemConfig config = new SystemConfig();
            config.setTotalSeats(totalSeats);
            config.setNumberOfShifts(numberOfShifts);
            config.setIsInitialized(true);
            
            systemConfigRepository.save(config);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public SystemConfig getSystemConfig() {
        try {
            SystemConfig config = systemConfigRepository.findFirstByOrderById();
            return config;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean updateSystemConfig(SystemConfig config) {
        try {
            systemConfigRepository.save(config);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
} 