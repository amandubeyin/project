package com.lms.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.models.Admin;
import com.lms.repositories.AdminRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public Admin authenticate(String username, String passwordHash) {
        try {
            Optional<Admin> adminOpt = adminRepository.findByUsername(username);
            if (adminOpt.isPresent()) {
                Admin admin = adminOpt.get();
                if (admin.getPasswordHash().equals(passwordHash)) {
                    return admin;
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean createAdmin(String username, String passwordHash, String email, String fullName, LocalDate dateOfBirth) {
        try {
            // Check if username already exists
            if (adminRepository.existsByUsername(username)) {
                return false;
            }
            Admin admin = new Admin(username, passwordHash, email, fullName, dateOfBirth);
            adminRepository.save(admin);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Admin getAdmin(Long id) {
        try {
            return adminRepository.findById(id).orElse(null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean updateAdmin(Admin admin) {
        try {
            if (adminRepository.existsById(admin.getId())) {
                adminRepository.save(admin);
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updatePassword(Long adminId, String newPasswordHash) {
        try {
            Optional<Admin> adminOpt = adminRepository.findById(adminId);
            if (adminOpt.isPresent()) {
                Admin admin = adminOpt.get();
                admin.setPasswordHash(newPasswordHash);
                adminRepository.save(admin);
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Admin> getAllAdmins() {
        try {
            return adminRepository.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public boolean resetPassword(String username, LocalDate dateOfBirth, String newPasswordHash) {
        try {
            Optional<Admin> adminOpt = adminRepository.findByUsername(username);
            if (adminOpt.isPresent()) {
                Admin admin = adminOpt.get();
                if (admin.getDateOfBirth().equals(dateOfBirth)) {
                    admin.setPasswordHash(newPasswordHash);
                    adminRepository.save(admin);
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateAdminProfile(Admin admin) {
        return updateAdmin(admin);
    }
} 