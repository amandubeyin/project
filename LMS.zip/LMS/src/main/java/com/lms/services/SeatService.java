package com.lms.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lms.models.Seat;
import com.lms.repositories.SeatRepository;

@Service
public class SeatService {
    
    private static final Logger logger = LoggerFactory.getLogger(SeatService.class);
    private final SeatRepository seatRepository;
    
    @Autowired
    public SeatService(SeatRepository seatRepository) {
        this.seatRepository = seatRepository;
    }
    
    public List<Seat> getAllSeats() {
        return seatRepository.findAll();
    }
    
    public List<Seat> getSeatsByFloor(String floor) {
        return seatRepository.findByFloor(floor);
    }
    
    public List<Seat> getAvailableSeats() {
        return seatRepository.findByIsAvailable(true);
    }
    
    public List<Seat> getAvailableSeatsByFloor(String floor) {
        return seatRepository.findByFloorAndIsAvailable(floor, true);
    }
    
    public List<String> getAllFloors() {
        return seatRepository.findAllFloors();
    }
    
    public Seat getSeatById(Long id) {
        return seatRepository.findById(id).orElse(null);
    }
    
    @Transactional
    public Seat createSeat(String floor, String seatNumber) {
        try {
            if (seatRepository.existsBySeatNumberAndFloor(seatNumber, floor)) {
                throw new IllegalArgumentException("Seat " + floor + "-" + seatNumber + " already exists");
            }
            
            Seat seat = new Seat();
            seat.setFloor(floor);
            seat.setSeatNumber(seatNumber);
            seat.setAvailable(true);
            
            return seatRepository.save(seat);
        } catch (Exception e) {
            logger.error("Error creating seat: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    @Transactional
    public List<Seat> createSeatsInBulk(String floor, int startNumber, int endNumber) {
        List<Seat> newSeats = new ArrayList<>();
        int successCount = 0;
        
        for (int i = startNumber; i <= endNumber; i++) {
            String seatNumber = String.valueOf(i);
            
            try {
                boolean exists = seatRepository.existsBySeatNumberAndFloor(seatNumber, floor);
                logger.debug("Checking seat {}-{}: exists = {}", floor, seatNumber, exists);
                
                if (!exists) {
                    Seat createdSeat = createSingleSeat(floor, seatNumber);
                    if (createdSeat != null) {
                        newSeats.add(createdSeat);
                        successCount++;
                    }
                }
            } catch (Exception e) {
                logger.error("Error processing seat {}-{}: {}", floor, seatNumber, e.getMessage());
            }
        }
        
        if (successCount == 0) {
            throw new IllegalArgumentException("No seats were created. All seats in the specified range may already exist.");
        }
        
        logger.info("Successfully created {} new seats in floor {}", successCount, floor);
        return newSeats;
    }
    
    @Transactional
    private Seat createSingleSeat(String floor, String seatNumber) {
        try {
            if (seatRepository.existsBySeatNumberAndFloor(seatNumber, floor)) {
                return null;
            }
            
            Seat seat = new Seat();
            seat.setFloor(floor);
            seat.setSeatNumber(seatNumber);
            seat.setAvailable(true);
            
            return seatRepository.save(seat);
        } catch (Exception e) {
            logger.error("Error saving seat {}-{}: {}", floor, seatNumber, e.getMessage(), e);
            return null;
        }
    }
    
    @Transactional
    public boolean deleteSeat(Long id) {
        if (seatRepository.existsById(id)) {
            seatRepository.deleteById(id);
            logger.info("Deleted seat with ID: {}", id);
            return true;
        }
        return false;
    }
    
    @Transactional
    public void deleteAllSeatsByFloor(String floor) {
        List<Seat> seatsToDelete = seatRepository.findByFloor(floor);
        seatRepository.deleteAll(seatsToDelete);
        logger.info("Deleted all {} seats in floor {}", seatsToDelete.size(), floor);
    }
    
    @Transactional
    public void deleteAllSeats() {
        try {
            seatRepository.deleteAll();
            logger.info("Successfully deleted all seats from database");
        } catch (Exception e) {
            logger.error("Error deleting all seats: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    public int getTotalSeats() {
        return seatRepository.countTotalSeats();
    }
    
    public int getAvailableSeatsCount() {
        return seatRepository.countAvailableSeats();
    }
    
    public int getSeatCountByFloor(String floor) {
        return seatRepository.countSeatsByFloor(floor);
    }
    
    public Map<String, Integer> getSeatCountsByFloor() {
        List<String> floors = seatRepository.findAllFloors();
        return floors.stream()
                .collect(Collectors.toMap(
                        floor -> floor,
                        this::getSeatCountByFloor
                ));
    }
    
    @Transactional
    public Seat toggleSeatAvailability(Long id) {
        Seat seat = seatRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Seat not found with ID: " + id));
        
        boolean newStatus = !seat.isAvailable();
        seat.setAvailable(newStatus);
        logger.info("Toggled seat availability for ID {}: now {}", id, newStatus ? "available" : "occupied");
        
        return seatRepository.save(seat);
    }
} 