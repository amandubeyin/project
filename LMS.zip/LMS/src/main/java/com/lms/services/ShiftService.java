package com.lms.services;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.models.Shift;
import com.lms.models.SystemConfig;
import com.lms.repositories.ShiftRepository;
import com.lms.repositories.SystemConfigRepository;

@Service
public class ShiftService {

    private final ShiftRepository shiftRepository;
    private final SystemConfigRepository systemConfigRepository;

    @Autowired
    public ShiftService(ShiftRepository shiftRepository, SystemConfigRepository systemConfigRepository) {
        this.shiftRepository = shiftRepository;
        this.systemConfigRepository = systemConfigRepository;
    }

    public Shift createShift(String shiftName, LocalTime startTime, LocalTime endTime) {
        Shift shift = new Shift();
        shift.setShiftName(shiftName);
        shift.setStartTime(startTime);
        shift.setEndTime(endTime);
        return shiftRepository.save(shift);
    }

    public List<Shift> getAllShifts() {
        return shiftRepository.findAllByOrderByStartTimeAsc();
    }
    
    /**
     * Convert shifts to array format for TableView
     * @return List of Object arrays containing shift data
     */
    public List<Object[]> getAllShiftsAsArray() {
        List<Shift> shifts = getAllShifts();
        List<Object[]> result = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        
        for (Shift shift : shifts) {
            Object[] row = new Object[3];
            row[0] = shift;
            row[1] = shift.getStartTime().format(formatter);
            row[2] = shift.getEndTime().format(formatter);
            result.add(row);
        }
        
        return result;
    }

    public void deleteShift(Long shiftId) {
        shiftRepository.deleteById(shiftId);
    }

    public Shift updateShift(Long shiftId, String shiftName, LocalTime startTime, LocalTime endTime) {
        Shift shift = shiftRepository.findById(shiftId)
                .orElseThrow(() -> new RuntimeException("Shift not found"));
        
        shift.setShiftName(shiftName);
        shift.setStartTime(startTime);
        shift.setEndTime(endTime);
        return shiftRepository.save(shift);
    }
    
    /**
     * Get the total number of seats configured in the system
     * @return Total number of seats
     */
    public int getTotalSeats() {
        SystemConfig config = systemConfigRepository.findFirstByOrderById();
        return config != null ? config.getTotalSeats() : 0;
    }
    
    /**
     * Get the total number of shifts in the system
     * @return Total number of shifts
     */
    public int getTotalShifts() {
        return (int) shiftRepository.count();
    }
} 