package com.lms.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * Manages JavaFX stages and scenes
 */
@Component
public class StageManager {

    private Stage primaryStage;
    private final Map<String, Scene> sceneCache = new HashMap<>();
    private final SpringFXMLLoader fxmlLoader;
    private final LibraryConfig libraryConfig;
    
    @Autowired
    public StageManager(SpringFXMLLoader fxmlLoader, LibraryConfig libraryConfig) {
        this.fxmlLoader = fxmlLoader;
        this.libraryConfig = libraryConfig;
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle(libraryConfig.getLibraryName() + " - Library Management System");
        
        // Make the application responsive to screen size
        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();
        
        // Set initial size to 90% of screen
        this.primaryStage.setWidth(bounds.getWidth() * 0.9);
        this.primaryStage.setHeight(bounds.getHeight() * 0.9);
        
        // Center the window
        this.primaryStage.centerOnScreen();
        
        // Set minimum size
        this.primaryStage.setMinWidth(1024);
        this.primaryStage.setMinHeight(768);
        
        // Add window state listeners
        this.primaryStage.maximizedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue) {
                // When maximized
                this.primaryStage.getScene().getRoot().setStyle("-fx-border-width: 0;");
            } else {
                // When restored
                this.primaryStage.getScene().getRoot().setStyle("-fx-border-width: 1; -fx-border-color: #1a237e;");
            }
        });
        
        // Apply drop shadow to primary stage
        this.primaryStage.setScene(new Scene(new StackPane()));
        this.primaryStage.getScene().getRoot().setStyle("-fx-background-color: transparent;");
        this.primaryStage.initStyle(StageStyle.DECORATED);
    }

    public void switchScene(String fxmlPath, String title) {
        try {
            Scene scene = sceneCache.get(fxmlPath);
            if (scene == null) {
                Parent root = fxmlLoader.load(fxmlPath);
                
                // Apply CSS to all scenes
                scene = new Scene(root);
                String cssPath = "/styles/application.css";
                if (getClass().getResource(cssPath) != null) {
                    scene.getStylesheets().add(getClass().getResource(cssPath).toExternalForm());
                }
                
                // Make all content responsive
                makeResponsive(root);
                
                // Add library config to scene properties for use in controllers
                scene.getProperties().put("libraryConfig", libraryConfig);
                
                sceneCache.put(fxmlPath, scene);
            }
            
            primaryStage.setTitle(libraryConfig.getLibraryName() + " - " + title);
            primaryStage.setScene(scene);
            
            // Ensure the scene fills the stage
            if (scene.getRoot() instanceof Region) {
                Region rootRegion = (Region) scene.getRoot();
                rootRegion.prefWidthProperty().bind(primaryStage.widthProperty());
                rootRegion.prefHeightProperty().bind(primaryStage.heightProperty());
            }
            
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error loading FXML file: " + fxmlPath);
        }
    }

    /**
     * Make the UI components responsive by binding their sizes to their parent containers
     */
    private void makeResponsive(Parent root) {
        // Make tables, panes and other containers fill their parents
        root.lookupAll(".table-view, .list-view, BorderPane, HBox, VBox, Pane, StackPane, AnchorPane, GridPane").forEach(node -> {
            if (node.getParent() != null) {
                if (node instanceof Region) {
                    Region region = (Region) node;
                    region.setMaxWidth(Double.MAX_VALUE);
                    region.setMaxHeight(Double.MAX_VALUE);
                }
            }
        });
        
        // Add responsive behavior to specific components
        root.lookupAll(".sidebar").forEach(node -> {
            if (node instanceof Region) {
                Region region = (Region) node;
                region.prefHeightProperty().bind(
                    ((Region) root).heightProperty().subtract(60) // Adjust for header and footer
                );
            }
        });
    }

    public void clearCache() {
        sceneCache.clear();
    }

    public void showLoginScreen() {
        switchScene("/fxml/login.fxml", "Admin Login");
    }

    public void showSetupScreen() {
        switchScene("/fxml/setup.fxml", "System Setup");
    }

    public void showDashboard() {
        switchScene("/fxml/dashboard.fxml", "Admin Dashboard");
    }

    public void showResetPassword() {
        switchScene("/fxml/reset-password.fxml", "Reset Password");
    }

    public void showLibrarySettings() {
        switchScene("/fxml/library-settings.fxml", "Library Settings");
    }

    public void showStudentManagement() {
        // Use shared container instead of full screen switch
        showContentInSharedContainer("/fxml/student-management.fxml", "Student Management");
    }

    public void showSeatManagement() {
        // Use shared container instead of full screen switch
        showContentInSharedContainer("/fxml/seat-management.fxml", "Seat Management");
    }

    public void showAdminProfile() {
        switchScene("/fxml/admin-profile.fxml", "Admin Profile");
    }

    // Method to show content in a shared container
    private void showContentInSharedContainer(String fxmlPath, String title) {
        try {
            // Get the current dashboard scene
            Scene dashboardScene = sceneCache.get("/fxml/dashboard.fxml");
            if (dashboardScene == null || dashboardScene.getRoot() == null) {
                // If dashboard isn't loaded, just switch to the requested scene
                switchScene(fxmlPath, title);
                return;
            }

            // Load the content to be shown
            Parent contentRoot = fxmlLoader.load(fxmlPath);
            
            // Find the content area in the dashboard
            Parent dashboardRoot = dashboardScene.getRoot();
            javafx.scene.Node contentArea = dashboardRoot.lookup("#contentArea");
            
            if (contentArea instanceof javafx.scene.layout.StackPane) {
                javafx.scene.layout.StackPane stackPane = (javafx.scene.layout.StackPane) contentArea;
                
                // Hide all existing children
                for (javafx.scene.Node child : stackPane.getChildren()) {
                    child.setVisible(false);
                }
                
                // Add new content if not already added
                boolean alreadyAdded = false;
                for (javafx.scene.Node child : stackPane.getChildren()) {
                    if (child.getId() != null && child.getId().equals(contentRoot.getId())) {
                        child.setVisible(true);
                        alreadyAdded = true;
                        break;
                    }
                }
                
                if (!alreadyAdded) {
                    stackPane.getChildren().add(contentRoot);
                }
                
                // Show the dashboard scene if not already shown
                if (primaryStage.getScene() != dashboardScene) {
                    primaryStage.setScene(dashboardScene);
                }
                
                primaryStage.setTitle(libraryConfig.getLibraryName() + " - " + title);
            } else {
                // If content area not found, fall back to switching the entire scene
                switchScene(fxmlPath, title);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error loading FXML file: " + fxmlPath);
        }
    }
} 