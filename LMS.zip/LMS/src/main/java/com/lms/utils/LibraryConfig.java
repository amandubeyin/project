package com.lms.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Configuration class for library settings
 */
@Component
public class LibraryConfig {
    
    @Value("${library.name:City Central Library}")
    private String libraryName;
    
    @Value("${library.address:123 Book Street, Cityville}")
    private String libraryAddress;
    
    @Value("${library.phone:(555) 123-4567}")
    private String libraryPhone;
    
    @Value("${library.email:contact@citycentrallibrary.org}")
    private String libraryEmail;
    
    @Value("${library.website:www.citycentrallibrary.org}")
    private String libraryWebsite;
    
    @Value("${library.logo:📚}")
    private String libraryLogo;
    
    // Getters
    public String getLibraryName() {
        return libraryName;
    }
    
    public String getLibraryAddress() {
        return libraryAddress;
    }
    
    public String getLibraryPhone() {
        return libraryPhone;
    }
    
    public String getLibraryEmail() {
        return libraryEmail;
    }
    
    public String getLibraryWebsite() {
        return libraryWebsite;
    }
    
    public String getLibraryLogo() {
        return libraryLogo;
    }
} 