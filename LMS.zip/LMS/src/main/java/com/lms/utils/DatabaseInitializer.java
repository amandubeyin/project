package com.lms.utils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class DatabaseInitializer implements ApplicationListener<ContextRefreshedEvent> {
    
    private static final Logger logger = LoggerFactory.getLogger(DatabaseInitializer.class);
    
    @PersistenceContext
    private EntityManager entityManager;
    
    private boolean initialized = false;
    
    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (initialized) {
            return; // Prevent multiple initializations
        }
        
        logger.info("Starting database initialization via ContextRefreshedEvent...");
        System.out.println("DATABASE INIT: Starting to create tables");
        
        try {
            // Create Admin table if it doesn't exist
            String createAdminTable = 
                "CREATE TABLE IF NOT EXISTS Admin (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username VARCHAR(50) NOT NULL UNIQUE, " +
                "passwordHash VARCHAR(100) NOT NULL, " +
                "email VARCHAR(100), " +
                "fullName VARCHAR(100)" +
                ")";
            
            // Create Seat table if it doesn't exist
            String createSeatTable = 
                "CREATE TABLE IF NOT EXISTS Seat (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "seatNumber VARCHAR(20) NOT NULL, " +
                "floor VARCHAR(20) NOT NULL, " +
                "isAvailable BOOLEAN NOT NULL DEFAULT 1, " +
                "student_id BIGINT, " +
                "shift_id BIGINT, " +
                "UNIQUE(floor, seatNumber)" +
                ")";
            
            // Create Student table if it doesn't exist
            String createStudentTable = 
                "CREATE TABLE IF NOT EXISTS Student (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name VARCHAR(100), " +
                "fatherName VARCHAR(100), " +
                "gender VARCHAR(10), " +
                "address VARCHAR(255), " +
                "mobileNo VARCHAR(20)" +
                ")";
            
            // Create Shift table if it doesn't exist
            String createShiftTable = 
                "CREATE TABLE IF NOT EXISTS Shift (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "shiftName VARCHAR(50), " +
                "startTime TIME, " +
                "endTime TIME" +
                ")";
            
            // Execute the SQL statements
            System.out.println("DATABASE INIT: Creating Admin table...");
            entityManager.createNativeQuery(createAdminTable).executeUpdate();
            logger.info("Admin table initialized");
            System.out.println("DATABASE INIT: Admin table created");
            
            // Insert default admin if not exists
            Integer adminCount = (Integer) entityManager.createNativeQuery("SELECT COUNT(*) FROM Admin WHERE username = 'admin'").getSingleResult();
            if (adminCount == 0) {
                String insertAdmin = 
                    "INSERT INTO Admin (id, username, passwordHash, email, fullName) " +
                    "VALUES (1, 'admin', 'admin', 'admin@library.com', 'System Administrator')";
                entityManager.createNativeQuery(insertAdmin).executeUpdate();
                logger.info("Default admin user created");
                System.out.println("DATABASE INIT: Default admin user created");
            }
            
            System.out.println("DATABASE INIT: Creating Student table...");
            entityManager.createNativeQuery(createStudentTable).executeUpdate();
            logger.info("Student table initialized");
            System.out.println("DATABASE INIT: Student table created");
            
            System.out.println("DATABASE INIT: Creating Shift table...");
            entityManager.createNativeQuery(createShiftTable).executeUpdate();
            logger.info("Shift table initialized");
            System.out.println("DATABASE INIT: Shift table created");
            
            System.out.println("DATABASE INIT: Creating Seat table...");
            entityManager.createNativeQuery(createSeatTable).executeUpdate();
            logger.info("Seat table initialized");
            System.out.println("DATABASE INIT: Seat table created");
            
            // Verify tables were created
            Integer seatCount = (Integer) entityManager.createNativeQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='Seat'").getSingleResult();
            logger.info("Seat table exists: {}", seatCount > 0);
            System.out.println("DATABASE INIT: Seat table exists: " + (seatCount > 0));
            
            // Log the structure of the database
            System.out.println("DATABASE INIT: Database tables structure:");
            entityManager.createNativeQuery("SELECT name FROM sqlite_master WHERE type='table'").getResultList()
                .forEach(tableName -> System.out.println("Table: " + tableName));
            
            initialized = true;
        } catch (Exception e) {
            logger.error("Error initializing database: {}", e.getMessage(), e);
            System.out.println("DATABASE INIT ERROR: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("DATABASE INIT: Initialization complete");
    }
} 