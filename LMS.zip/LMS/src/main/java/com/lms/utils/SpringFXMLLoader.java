package com.lms.utils;

import java.io.IOException;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.util.Callback;

/**
 * Utility class for loading FXML files with Spring integration
 */
@Component
public class SpringFXMLLoader {
    
    private final ApplicationContext applicationContext;
    
    public SpringFXMLLoader(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }
    
    /**
     * Loads an FXML file and returns the root node
     */
    public Parent load(String fxmlPath) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(fxmlPath));
        loader.setControllerFactory(new SpringControllerFactory());
        return loader.load();
    }
    
    /**
     * Loads an FXML file and returns the FXMLLoader for accessing the controller
     */
    public FXMLLoader getLoader(String fxmlPath) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(fxmlPath));
        loader.setControllerFactory(new SpringControllerFactory());
        return loader;
    }
    
    /**
     * Controller factory that uses Spring to instantiate controllers
     */
    private class SpringControllerFactory implements Callback<Class<?>, Object> {
        @Override
        public Object call(Class<?> type) {
            try {
                // First try to get the bean from Spring context
                return applicationContext.getBean(type);
            } catch (Exception e) {
                try {
                    // If no bean is found, create a new instance
                    return type.getDeclaredConstructor().newInstance();
                } catch (Exception ex) {
                    throw new RuntimeException("Failed to create controller", ex);
                }
            }
        }
    }
} 