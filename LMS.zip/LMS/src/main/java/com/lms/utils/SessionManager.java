package com.lms.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lms.models.Admin;
import com.lms.services.AdminService;

/**
 * Manages user sessions and authentication
 */
@Component
public class SessionManager {
    
    private Admin currentAdmin;
    private boolean loggedIn = false;
    
    private final AdminService adminService;
    
    @Autowired
    public SessionManager(AdminService adminService) {
        this.adminService = adminService;
    }
    
    /**
     * Login the user with the provided admin object
     * @param admin The authenticated admin user
     */
    public void login(Admin admin) {
        if (admin != null) {
            currentAdmin = admin;
            loggedIn = true;
        }
    }
    
    /**
     * Get the currently logged in admin
     * @return The current Admin or null if no user is logged in
     */
    public Admin getCurrentAdmin() {
        return currentAdmin;
    }
    
    /**
     * Set the current admin (used when updating admin profile)
     * @param admin The updated admin object
     */
    public void setCurrentAdmin(Admin admin) {
        currentAdmin = admin;
    }
    
    /**
     * Check if a user is currently logged in
     * @return True if there is a logged in user
     */
    public boolean isLoggedIn() {
        return loggedIn;
    }
    
    /**
     * Logout the current user
     */
    public void logout() {
        currentAdmin = null;
        loggedIn = false;
    }
    
    /**
     * Attempt to authenticate a user with the given credentials
     * @param username Username to authenticate
     * @param password Password to authenticate
     * @return True if authentication was successful
     */
    public boolean authenticate(String username, String password) {
        // Simple password hashing (in a real app, use a proper hashing library)
        String hashedPassword = String.valueOf(password.hashCode());
        
        Admin admin = adminService.authenticate(username, hashedPassword);
        
        if (admin != null) {
            login(admin);
            return true;
        }
        
        return false;
    }
} 