package com.lms.utils;

import com.lms.LibraryManagementSystemApplication;
import com.lms.services.SystemInitializationService;
import javafx.stage.Stage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class StageListener implements ApplicationListener<LibraryManagementSystemApplication.StageReadyEvent> {

    private final StageManager stageManager;
    private final SystemInitializationService systemInitService;

    @Autowired
    public StageListener(StageManager stageManager, SystemInitializationService systemInitService) {
        this.stageManager = stageManager;
        this.systemInitService = systemInitService;
    }

    @Override
    public void onApplicationEvent(LibraryManagementSystemApplication.StageReadyEvent event) {
        Stage stage = event.getStage();
        stageManager.setPrimaryStage(stage);
        
        // Check if system is initialized
        if (systemInitService.isSystemInitialized()) {
            stageManager.showLoginScreen();
        } else {
            stageManager.showSetupScreen();
        }
    }
} 