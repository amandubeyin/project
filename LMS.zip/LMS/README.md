# Library Management System

A desktop application built with Spring Boot, JavaFX, and SQLite.

## Prerequisites

- Java 17 or higher
- Maven

## Running the Application

```bash
# Build and run the application
mvn clean javafx:run
```

## Features

- Admin authentication
- System configuration setup
- Shift management
- Password reset functionality


## Tech Stack

- Spring Boot
- JavaFX
- SQLite
- JPA/Hibernate 